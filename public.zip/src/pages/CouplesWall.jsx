import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { db } from "../firebase";
import {
  collection,
  addDoc,
  onSnapshot,
  serverTimestamp,
  orderBy,
  query,
} from "firebase/firestore";

// TEMP static couples images
import couple1 from "../assets/couple1.jpg";
import couple2 from "../assets/couple2.jpg";
import couple3 from "../assets/couple3.jpg";

const CouplesWall = () => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState({ name: "", message: "" });

  // Realtime listener
  useEffect(() => {
    const q = query(
      collection(db, "freedomWall"),
      orderBy("timestamp", "desc")
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setComments(
        snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
      );
    });
    return unsubscribe;
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.name || !newComment.message) return;

    await addDoc(collection(db, "freedomWall"), {
      name: newComment.name,
      message: newComment.message,
      timestamp: serverTimestamp(),
    });

    setNewComment({ name: "", message: "" });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-black py-16 px-6"
    >
      <div className="max-w-6xl mx-auto text-center space-y-16">
        {/* Title */}
        <motion.h1
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="text-5xl font-extrabold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent"
        >
          💞 Couples Wall
        </motion.h1>

        {/* Couples Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[couple1, couple2, couple3].map((img, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.05 }}
              className="rounded-2xl overflow-hidden shadow-lg border border-gray-700/40"
            >
              <img
                src={img}
                alt={`Couple ${i + 1}`}
                className="w-full h-64 object-cover"
              />
            </motion.div>
          ))}
        </div>

        {/* Freedom Wall */}
        <div className="bg-gray-800/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 shadow-xl text-left max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-cyan-400 mb-6">📝 Freedom Wall</h2>

          {/* Comment List */}
          <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
            {comments.length === 0 ? (
              <p className="text-gray-400">No messages yet. Be the first!</p>
            ) : (
              comments.map((c) => (
                <div
                  key={c.id}
                  className="bg-gray-900/50 rounded-lg p-4 border border-gray-700/40"
                >
                  <p className="text-white font-semibold">{c.name}</p>
                  <p className="text-gray-300">{c.message}</p>
                </div>
              ))
            )}
          </div>

          {/* Comment Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Your name or couple name"
              value={newComment.name}
              onChange={(e) =>
                setNewComment({ ...newComment, name: e.target.value })
              }
              className="w-full px-4 py-2 rounded-lg bg-gray-900/70 text-white border border-gray-700 focus:outline-none focus:border-cyan-400"
            />
            <textarea
              placeholder="Leave a message..."
              value={newComment.message}
              onChange={(e) =>
                setNewComment({ ...newComment, message: e.target.value })
              }
              className="w-full px-4 py-2 rounded-lg bg-gray-900/70 text-white border border-gray-700 focus:outline-none focus:border-cyan-400"
              rows="3"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-500 text-white font-semibold shadow-lg hover:opacity-90 transition"
            >
              Post Message
            </button>
          </form>
        </div>
      </div>
    </motion.div>
  );
};

export default CouplesWall;
