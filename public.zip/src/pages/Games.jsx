import React, { useState } from "react";
import GameModal from "./GameModal";

const games = [
  {
    id: 1,
    title: "Italian Brainrot Bike Rush",
    embedUrl:
      "https://html5.gamedistribution.com/c23f50871019481f99d1ce3d56571dfd/?gd_sdk_referrer_url=https://gamedistribution.com/games/italian-brainrot-bike-rush/",
  },
];

const Games = () => {
  const [selectedGame, setSelectedGame] = useState(null);

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h2 className="text-3xl font-bold text-center mb-10 text-cyan-400">
        🎮 Browse Free Games
      </h2>
      <div className="grid md:grid-cols-3 gap-6">
        {games.map((game) => (
          <div
            key={game.id}
            className="bg-gray-900 rounded-lg p-4 border border-cyan-600 shadow-lg hover:scale-105 transition-transform"
          >
            <h3 className="text-xl font-bold text-pink-400 mb-2">
              {game.title}
            </h3>
            <button
              onClick={() => setSelectedGame(game)}
              className="inline-block mt-3 px-4 py-2 bg-cyan-600 rounded hover:bg-cyan-700 text-white text-sm"
            >
              Play Now
            </button>
          </div>
        ))}
      </div>

      {selectedGame && (
        <GameModal game={selectedGame} onClose={() => setSelectedGame(null)} />
      )}
    </div>
  );
};

export default Games;
